<?php
	$name = 'Brittany';
	$age = '25';
	$distance = '13.1';

	echo "<html>";
	echo "<title> HTML created instide PHP </title>";
	echo "<p>Hello, my name is $name.</p>";
	echo "<p>I am $age years old.</p>";
	echo "<p>on my 26th birthday I will be running $distance miles.</p>";
	echo "</html>";
 ?>
 <!-- end PHP -->

