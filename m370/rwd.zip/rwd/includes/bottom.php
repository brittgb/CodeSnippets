<footer>
  <p>`Oh, I've had such a curious dream!' said Alice</p>
  <p><a href="http://jigsaw.w3.org/css-validator/check/referer">Valid CSS</a> and <a href="http://validator.w3.org/check/referer">Valid HTML5</a> ~ Website by (your name here), copyright 2014</p>
</footer>
</body>
</html>