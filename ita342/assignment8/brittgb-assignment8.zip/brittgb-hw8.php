<!DOCTYPE html>
<html>

<form action="search.php" method="post">
	Enter the photographer's name (or part thereof):
	<input type="text" name="photographer" />
	<input type="submit" value="Search" />
</form> 
</html>