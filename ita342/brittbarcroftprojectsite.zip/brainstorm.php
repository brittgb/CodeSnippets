<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Britt's ITA 342 site</title>
		<meta charset="utf-8"/>
		<link rel="stylesheet" type="text/css" href="mystyle.css">
		<style type="text/css">
		</style>
	</head>	
		<body>
			<h1>Britt's Final Project</h1>
			<p>
				Brainstorm:
				<br /><br />
				Users:
				USER ID,
				password,
				first name,
				last name,
				email,
				phone number,
				shipping address,
				billing address,
				credit card information (be extra areful when designing this!!!),
				email verification
				<br /><br />
				Books:
				publisher ID,
				name,
				address,
				book ID,
				title,
				author,
				ISBN,
				publication year,
				binding,
				price new,
				price used,
				book weight,
				book dimensions,
				stock,
				product image
				<br /><br />
				Shopping Cart:
				cart ID,
				book IDs,
				price,
				user ID
				<br /><br />
				Orders: 
				order ID,
				order placed timestamp,
				USER ID,
				book IDs,
				price,
				tax,
				total,
				tracking number,
				shipping method/speed,
				order ship date,
				estimated arrival date
				<br /><br />




			 </p>
		</body>
</html>	