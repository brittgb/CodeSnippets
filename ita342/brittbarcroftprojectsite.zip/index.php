<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Britt's ITA 342 site</title>
		<meta charset="utf-8"/>
		<link rel="stylesheet" type="text/css" href="mystyle.css">
		<style type="text/css">
		</style>
	</head>	
		<body>
			<h1>Britt's Final Project</h1>
			<p>I've decided to take on something that will involve a bit more work on my part than the assignment requirements call for.  Online shopping carts are becoming more and more common, so I'd like to build a simple one to use as a quality portfolio piece with a good interface.  For the sake of simplicity, I'll be cataloging the books on my bookshelf and creating a fake used bookstore.  </p>
			<br />
			<a href="brainstorm.php">brainstorm</a>
		</body>
</html>	